SBL 1.0 resolved page rendering package
Render target: CH7-P001
Entry file: CH7-P001.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Midori-age11-expression-sheet.png
  Assets/WOA-production-sheet-plus-map.png
  Assets/Midori-Age-11-Canonical-Character-Specification-v2.txt
  Assets/Midori-age11-character-reference-sheet.png
  Assets/WOA-production-sheet.png
  Assets/WOA-canonical-production-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
