SBL 1.0 resolved page rendering package
Render target: CH7-P023
Entry file: CH7-P023.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Haru-canonical-character-specification.txt
  Assets/Midori-Age-11-Canonical-Character-Specification-v2.txt
  Assets/Takeshi-expression-sheet.png
  Assets/Emi-character-Sheet.png
  Assets/Takeshi-character-reference-sheet.png
  Assets/Haru-character-sheet.png
  Assets/Midori-age11-character-reference-sheet.png
  Assets/Midori-age11-expression-sheet.png
  Assets/Emi-Expression-Sheet.png
  Assets/Emi-canonical-character-specification.txt
  Assets/Aokawa-Village-production-sheet.png
  Assets/Takeshi-Canonical-Character-Specification.txt
  Assets/Haru-expression-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
