SBL 1.0 resolved page rendering package
Render target: CH7-P049
Entry file: CH7-P049.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Terra-expression-sheet.png
  Assets/Emi-character-Sheet.png
  Assets/Haru-character-sheet.png
  Assets/Emi-canonical-character-specification.txt
  Assets/Haru-expression-sheet.png
  Assets/Emi-Expression-Sheet.png
  Assets/Terra-character-sheet.png
  Assets/Terra-canonical-character-specification.txt
  Assets/SRA-production-sheet.png
  Assets/Haru-canonical-character-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
