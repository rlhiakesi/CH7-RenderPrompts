SBL 1.0 resolved page rendering package
Render target: CH7-P003
Entry file: CH7-P003.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/WOA-canonical-production-specification.txt
  Assets/WOA-production-sheet-plus-map.png
  Assets/Terra-expression-sheet.png
  Assets/Zorna-character-sheet.png
  Assets/Terra-character-sheet.png
  Assets/Zorna-canonical-character-specification(1).txt
  Assets/Terra-canonical-character-specification.txt
  Assets/Zorna-expression-sheet.png
  Assets/WOA-production-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
