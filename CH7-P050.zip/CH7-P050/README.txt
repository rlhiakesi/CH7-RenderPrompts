SBL 1.0 resolved page rendering package
Render target: CH7-P050
Entry file: CH7-P050.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Emi-canonical-character-specification.txt
  Assets/Haru-character-sheet.png
  Assets/Emi-Expression-Sheet.png
  Assets/Terra-canonical-character-specification.txt
  Assets/SRA-production-sheet.png
  Assets/Terra-character-sheet.png
  Assets/Emi-character-Sheet.png
  Assets/Midori-age11-expression-sheet.png
  Assets/Haru-expression-sheet.png
  Assets/Terra-expression-sheet.png
  Assets/Haru-canonical-character-specification.txt
  Assets/Midori-age11-character-reference-sheet.png
  Assets/Midori-Age-11-Canonical-Character-Specification-v2.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
