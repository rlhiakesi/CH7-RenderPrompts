SBL 1.0 resolved page rendering package
Render target: CH7-P007
Entry file: CH7-P007.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Truk-expression-sheet.png
  Assets/Kamakura-Generic-Personnel-reference-sheet.png
  Assets/Truk-character-reference-sheet.png
  Assets/Truk-canonical-character-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
